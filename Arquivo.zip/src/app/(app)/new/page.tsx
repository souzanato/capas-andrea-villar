import CoverWizard from "@/components/CoverWizard";

export default function NewCoverPage() {
  return (
    <div className="py-8">
      <CoverWizard />
    </div>
  );
}
