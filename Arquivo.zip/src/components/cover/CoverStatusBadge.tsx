import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";

const STATUS_CONFIG: Record<
  string,
  { label: string; className: string; icon?: React.ReactNode }
> = {
  PENDING: {
    label: "Aguardando",
    className: "bg-yellow-100 text-yellow-900 hover:bg-yellow-100",
    icon: <Loader2 className="h-3 w-3 animate-spin" />,
  },
  GENERATING_PROMPT: {
    label: "Gerando prompt",
    className: "bg-blue-100 text-blue-900 hover:bg-blue-100",
    icon: <Loader2 className="h-3 w-3 animate-spin" />,
  },
  GENERATING_IMAGE: {
    label: "Gerando imagem",
    className: "bg-blue-100 text-blue-900 hover:bg-blue-100",
    icon: <Loader2 className="h-3 w-3 animate-spin" />,
  },
  COMPLETED: {
    label: "Concluída",
    className: "bg-green-100 text-green-900 hover:bg-green-100",
  },
  FAILED: {
    label: "Erro",
    className: "bg-red-100 text-red-900 hover:bg-red-100",
  },
};

interface CoverStatusBadgeProps {
  status: string;
}

export default function CoverStatusBadge({ status }: CoverStatusBadgeProps) {
  const config = STATUS_CONFIG[status] ?? {
    label: status,
    className: "bg-gray-100 text-gray-900",
  };

  return (
    <Badge className={cn("gap-1 font-medium", config.className)} variant="outline">
      {config.icon}
      {config.label}
    </Badge>
  );
}
