"use client";

import { Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface CoverGeneratingProps {
  status: string;
}

const STAGE_CONFIG: Record<
  string,
  { label: string; message: string; step: number }
> = {
  PENDING: {
    label: "Aguardando",
    message: "Seu pedido está na fila para processamento.",
    step: 0,
  },
  GENERATING_PROMPT: {
    label: "Gerando prompt",
    message:
      "GPT-4o está criando o prompt tipográfico ideal para sua capa.",
    step: 1,
  },
  GENERATING_IMAGE: {
    label: "Renderizando imagem",
    message:
      "Gemini está aplicando o texto sobre a imagem base. Pode levar alguns segundos.",
    step: 2,
  },
};

export default function CoverGenerating({ status }: CoverGeneratingProps) {
  const config = STAGE_CONFIG[status] ?? STAGE_CONFIG.PENDING;

  return (
    <div className="space-y-8">
      {/* Pipeline steps */}
      <div className="rounded-lg border bg-card p-6 space-y-4">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
          Pipeline
        </h2>
        <div className="space-y-3">
          {["Aguardando", "Gerando prompt", "Renderizando imagem"].map(
            (label, index) => {
              const isActive = index === config.step;
              const isDone = index < config.step;

              return (
                <div key={label} className="flex items-center gap-3">
                  <div
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                      isDone
                        ? "bg-primary text-primary-foreground"
                        : isActive
                          ? "border-2 border-primary"
                          : "border-2 border-muted-foreground/30 text-muted-foreground/50"
                    }`}
                  >
                    {isDone ? (
                      <svg
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={3}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    ) : isActive ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      index + 1
                    )}
                  </div>
                  <span
                    className={`text-sm ${
                      isDone
                        ? "text-muted-foreground line-through"
                        : isActive
                          ? "font-medium text-foreground"
                          : "text-muted-foreground/50"
                    }`}
                  >
                    {label}
                  </span>
                </div>
              );
            }
          )}
        </div>
      </div>

      {/* Contextual message */}
      <div className="rounded-lg border bg-blue-50/50 p-4">
        <p className="text-sm text-blue-800">{config.message}</p>
      </div>

      {/* Skeleton placeholder */}
      <div className="w-full max-w-[500px] mx-auto space-y-3">
        <Skeleton className="aspect-[4/5] w-full rounded-lg" />
        <div className="flex justify-center gap-2">
          <Skeleton className="h-8 w-24 rounded-md" />
          <Skeleton className="h-8 w-28 rounded-md" />
        </div>
      </div>
    </div>
  );
}
