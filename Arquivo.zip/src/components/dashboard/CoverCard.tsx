"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  MoreHorizontal,
  Eye,
  Copy,
  Trash2,
  Image as ImageIcon,
  Loader2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const STATUS_CONFIG: Record<
  string,
  { label: string; className: string }
> = {
  PENDING: {
    label: "Aguardando",
    className: "bg-yellow-100 text-yellow-800",
  },
  GENERATING_PROMPT: {
    label: "Gerando prompt",
    className: "bg-blue-100 text-blue-800",
  },
  GENERATING_IMAGE: {
    label: "Renderizando",
    className: "bg-blue-100 text-blue-800",
  },
  COMPLETED: {
    label: "Concluída",
    className: "bg-green-100 text-green-800",
  },
  FAILED: {
    label: "Erro",
    className: "bg-red-100 text-red-800",
  },
};

const ASPECT_MAP: Record<string, string> = {
  REELS_9_16: "aspect-[9/16]",
  FEED_1_1: "aspect-square",
  CAROUSEL_4_5: "aspect-[4/5]",
};

interface CoverCardCover {
  id: string;
  title: string;
  format: string;
  status: string;
  createdAt: string;
  generatedImages: Array<{
    id: string;
    version: number;
    width: number;
    height: number;
  }>;
}

interface CoverCardProps {
  cover: CoverCardCover;
}

function formatRelativeTime(isoString: string): string {
  const date = new Date(isoString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);

  if (diffMin < 1) return "agora";
  if (diffMin < 60) return `há ${diffMin}min`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `há ${diffHr}h`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 7) return `há ${diffDay}d`;
  if (diffDay < 30) return `há ${Math.floor(diffDay / 7)}sem`;
  return date.toLocaleDateString("pt-BR");
}

export default function CoverCard({ cover }: CoverCardProps) {
  const router = useRouter();
  const [imageError, setImageError] = useState(false);
  const [duplicating, setDuplicating] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const statusConfig = STATUS_CONFIG[cover.status] ?? {
    label: cover.status,
    className: "bg-gray-100 text-gray-800",
  };

  const aspectClass = ASPECT_MAP[cover.format] ?? "aspect-[4/5]";
  const hasImage =
    cover.status === "COMPLETED" && cover.generatedImages.length > 0;
  const thumbnailUrl = `/api/covers/${cover.id}/image`;

  async function handleDuplicate(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDuplicating(true);
    try {
      const res = await fetch(`/api/covers/${cover.id}/duplicate`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Falha ao duplicar");
      const data = await res.json();
      router.push(`/cover/${data.newCoverId}`);
    } catch {
      toast.error("Erro ao duplicar capa");
      setDuplicating(false);
    }
  }

  async function handleDelete(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDeleting(true);
    try {
      const res = await fetch(`/api/covers/${cover.id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Falha ao excluir");
      toast.success("Capa excluída");
      router.refresh();
    } catch {
      toast.error("Erro ao excluir capa");
      setDeleting(false);
    }
  }

  return (
    <Link
      href={`/cover/${cover.id}`}
      className="group block rounded-lg border bg-card overflow-hidden transition-all hover:shadow-lg hover:ring-2 hover:ring-primary/20"
    >
      {/* Thumbnail area */}
      <div className={`relative ${aspectClass} bg-muted/50`}>
        {hasImage && !imageError ? (
          <img
            src={thumbnailUrl}
            alt={cover.title}
            className="absolute inset-0 w-full h-full object-cover"
            loading="lazy"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground/40 gap-2">
            <ImageIcon className="h-10 w-10" />
            <span className="text-xs">
              {imageError ? "Erro ao carregar" : hasImage ? "Carregando..." : "Sem imagem"}
            </span>
          </div>
        )}

        {/* Status badge */}
        <span
          className={`absolute top-2 left-2 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${statusConfig.className}`}
        >
          {cover.status === "PENDING" ||
          cover.status === "GENERATING_PROMPT" ||
          cover.status === "GENERATING_IMAGE" ? (
            <Loader2 className="h-2.5 w-2.5 animate-spin mr-1" />
          ) : null}
          {statusConfig.label}
        </span>

        {/* Actions menu */}
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="secondary"
                size="icon"
                className="h-7 w-7 bg-background/80 backdrop-blur-sm"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
              >
                <MoreHorizontal className="h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              <DropdownMenuItem
                onClick={() => router.push(`/cover/${cover.id}`)}
              >
                <Eye className="h-4 w-4 mr-2" />
                Ver detalhe
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDuplicate} disabled={duplicating}>
                {duplicating ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Copy className="h-4 w-4 mr-2" />
                )}
                Duplicar
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={handleDelete}
                disabled={deleting}
                className="text-destructive focus:text-destructive"
              >
                {deleting ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="h-4 w-4 mr-2" />
                )}
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Card footer */}
      <div className="p-3 space-y-1">
        <p className="text-sm font-medium truncate">{cover.title}</p>
        <p className="text-xs text-muted-foreground">
          {formatRelativeTime(cover.createdAt)}
        </p>
      </div>
    </Link>
  );
}
