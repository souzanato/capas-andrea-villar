import Link from "next/link";
import { ImageOff, SearchX, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmptyStateProps {
  variant: "no-covers" | "no-results";
  onClearFilters?: () => void;
}

export default function EmptyState({
  variant,
  onClearFilters,
}: EmptyStateProps) {
  if (variant === "no-covers") {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <ImageOff className="h-8 w-8 text-muted-foreground/60" />
        </div>
        <div className="text-center space-y-1">
          <h3 className="text-lg font-semibold">Nenhuma capa ainda</h3>
          <p className="text-sm text-muted-foreground max-w-sm">
            Você ainda não gerou nenhuma capa. Crie sua primeira capa
            e veja o resultado em segundos.
          </p>
        </div>
        <Button asChild>
          <Link href="/new">
            <Plus className="h-4 w-4 mr-2" />
            Criar primeira capa
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
        <SearchX className="h-8 w-8 text-muted-foreground/60" />
      </div>
      <div className="text-center space-y-1">
        <h3 className="text-lg font-semibold">Nenhum resultado</h3>
        <p className="text-sm text-muted-foreground max-w-sm">
          Nenhuma capa encontrada com esses critérios. Tente ajustar a
          busca ou os filtros.
        </p>
      </div>
      {onClearFilters && (
        <Button variant="outline" onClick={onClearFilters}>
          Limpar filtros
        </Button>
      )}
    </div>
  );
}
